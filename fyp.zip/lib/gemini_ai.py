import google.generativeai as genai
import streamlit as st
import json
import time

class GeminiScheduler:
    """Google Gemini AI for intelligent schedule generation"""
    
    def __init__(self):
        api_key = st.secrets["gemini"]["api_key"]
        genai.configure(api_key=api_key)
        self.model = genai.GenerativeModel('gemini-2.5-flash')
        
        # Generation config for better control
        self.generation_config = {
            "temperature": 0.7,
            "top_p": 0.95,
            "top_k": 40,
            "max_output_tokens": 8192,
        }
    
    def generate_schedule_suggestions(self, entities, constraints, context="", config=None):
        """Generate schedule using Gemini AI"""
        prompt = self.build_prompt(entities, constraints, context, config)
        
        try:
            response = self.model.generate_content(
                prompt,
                generation_config=self.generation_config
            )
            return self.parse_response(response.text)
        except Exception as e:
            st.error(f"Gemini API error: {e}")
            return None
    
    def build_prompt(self, entities, constraints, context, config):
        """Build detailed prompt for Gemini"""
        
        # Extract available time slots and resources from config
        days = config.get("days", ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"]) if config else ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"]
        time_slots = config.get("time_slots", ["08:00", "09:00", "10:00", "11:00", "12:00", "13:00", "14:00", "15:00", "16:00", "17:00"]) if config else ["08:00", "09:00", "10:00", "11:00", "12:00", "13:00", "14:00", "15:00", "16:00", "17:00"]
        rooms = config.get("rooms", ["R101", "R102", "R103", "R104", "R105"]) if config else ["R101", "R102", "R103", "R104", "R105"]
        
        return f"""
You are an expert scheduling optimization AI assistant. Generate an optimal timetable schedule.

AVAILABLE RESOURCES:
Days: {json.dumps(days)}
Time Slots: {json.dumps(time_slots)}
Rooms: {json.dumps(rooms)}

ENTITIES TO SCHEDULE:
{json.dumps(entities, indent=2)}

CONSTRAINTS TO RESPECT:
{json.dumps(constraints, indent=2)}

{f"ADDITIONAL CONTEXT: {context}" if context else ""}

REQUIREMENTS:
1. **Hard Constraints** (MUST be satisfied):
   - No overlapping: Same room cannot have two entities at same time
   - Availability: Respect entity availability constraints
   - Room capacity: Ensure room capacity meets entity requirements

2. **Soft Constraints** (Should optimize):
   - Preferred times: Try to schedule entities at preferred times
   - Balanced distribution: Distribute slots evenly across days
   - Minimize gaps: Reduce idle time between consecutive slots
   - Consecutive slots: Group related sessions together when possible

3. **Optimization Goals**:
   - Maximize constraint satisfaction
   - Minimize conflicts and violations
   - Create a practical, usable schedule
   - Balance workload across the week

OUTPUT FORMAT (Return ONLY valid JSON array, no markdown):
[
  {{
    "entity_id": "exact_entity_id_from_input",
    "entity_name": "entity name for reference",
    "day": "Monday",
    "time": "09:00",
    "room": "R101",
    "duration": 2,
    "confidence": 0.95,
    "reasoning": "Brief explanation of why this slot was chosen"
  }}
]

CRITICAL RULES:
- Return ONLY the JSON array, no additional text or markdown formatting
- Use exact entity_id values from the input entities
- Ensure all time slots are from the available time_slots list
- Ensure all days are from the available days list
- Ensure all rooms are from the available rooms list
- Each entity must appear exactly once in the schedule
- No two entities should occupy the same room at the same time

Generate the optimal schedule now:
"""
    
    def parse_response(self, response_text):
        """Parse Gemini response and extract JSON"""
        try:
            # Remove markdown code blocks if present
            text = response_text.strip()
            if text.startswith("```"):
                text = text.split("```")[1]
                if text.startswith("json"):
                    text = text[4:]
            
            # Extract JSON array
            start = text.find('[')
            end = text.rfind(']') + 1
            
            if start >= 0 and end > start:
                json_str = text[start:end]
                schedule = json.loads(json_str)
                return schedule
            
            # If no array found, try parsing entire text
            return json.loads(text)
            
        except json.JSONDecodeError as e:
            st.error(f"Failed to parse Gemini response as JSON: {e}")
            st.text("Raw response:")
            st.code(response_text)
            return []
        except Exception as e:
            st.error(f"Error parsing response: {e}")
            return []
    
    def analyze_schedule(self, schedule, constraints):
        """Get AI analysis of schedule quality"""
        prompt = f"""
Analyze this schedule and provide comprehensive insights:

SCHEDULE:
{json.dumps(schedule, indent=2)}

CONSTRAINTS:
{json.dumps(constraints, indent=2)}

Provide a detailed analysis with:
1. Overall quality score (0-100)
2. List of constraint violations (if any) with severity
3. Specific optimization suggestions with priorities
4. Key strengths of the current schedule
5. Critical weaknesses that need attention
6. Alternative approaches or improvements

Return as JSON:
{{
  "quality_score": 85,
  "violations": [
    {{"type": "overlap", "severity": "high", "description": "Room R101 has overlapping sessions"}}
  ],
  "suggestions": [
    {{"priority": "high", "suggestion": "Move session X to avoid conflict"}}
  ],
  "strengths": ["Good time distribution", "No availability conflicts"],
  "weaknesses": ["Unbalanced daily workload", "Too many gaps on Wednesday"],
  "alternatives": ["Consider swapping sessions A and B for better flow"]
}}

Return ONLY the JSON object, no markdown:
"""
        try:
            response = self.model.generate_content(prompt)
            return self.parse_analysis_response(response.text)
        except Exception as e:
            return {"error": str(e)}
    
    def parse_analysis_response(self, response_text):
        """Parse analysis response"""
        try:
            text = response_text.strip()
            if text.startswith("```"):
                text = text.split("```")[1]
                if text.startswith("json"):
                    text = text[4:]
            
            start = text.find('{')
            end = text.rfind('}') + 1
            
            if start >= 0 and end > start:
                json_str = text[start:end]
                return json.loads(json_str)
            
            return json.loads(text)
        except Exception as e:
            return {"error": f"Failed to parse analysis: {str(e)}"}
    
    def suggest_improvements(self, schedule, fitness_score, constraints):
        """Get AI suggestions for improving low-scoring schedules"""
        prompt = f"""
This schedule has a fitness score of {fitness_score:.2f}. Suggest specific improvements.

CURRENT SCHEDULE:
{json.dumps(schedule, indent=2)}

CONSTRAINTS:
{json.dumps(constraints, indent=2)}

Provide 3-5 concrete, actionable improvements:
Return as JSON array:
[
  {{
    "action": "Swap entity X from Monday 9:00 to Tuesday 10:00",
    "reason": "Reduces room conflicts and improves distribution",
    "expected_improvement": "15-20 points"
  }}
]

Return ONLY the JSON array:
"""
        try:
            response = self.model.generate_content(prompt)
            return self.parse_response(response.text)
        except Exception as e:
            return []


class HybridOptimizer:
    """Combines Gemini AI with Genetic Algorithm for optimal scheduling"""
    
    def __init__(self, entities, constraints, config=None):
        self.entities = entities
        self.constraints = constraints
        self.config = config or {}
        self.gemini = GeminiScheduler()
        self.ga = None
    
    def optimize(self, method="hybrid", progress_callback=None):
        """Run optimization with selected method"""
        
        if method == "gemini":
            return self.optimize_with_gemini(progress_callback)
        
        elif method == "genetic":
            return self.optimize_with_ga(progress_callback)
        
        elif method == "hybrid":
            return self.optimize_hybrid(progress_callback)
        
        else:
            raise ValueError(f"Unknown optimization method: {method}")
    
    def optimize_with_gemini(self, progress_callback):
        """Pure Gemini AI optimization"""
        if progress_callback:
            progress_callback(0, 0, 0, 0, "Initializing Gemini AI...")
        
        time.sleep(0.5)
        
        if progress_callback:
            progress_callback(0, 0, 0, 0, "Sending request to Gemini API...")
        
        schedule = self.gemini.generate_schedule_suggestions(
            self.entities, 
            self.constraints,
            config=self.config
        )
        
        if progress_callback:
            progress_callback(0, 0, 0, 0, "Processing AI response...")
        
        time.sleep(0.3)
        
        if progress_callback:
            progress_callback(0, 0, 0, 0, "Complete!")
        
        return {
            "schedule": schedule or [],
            "method": "gemini",
            "fitness": None,
            "history": []
        }
    
    def optimize_with_ga(self, progress_callback):
        """Pure genetic algorithm optimization"""
        from lib.genetic_algo import ScheduleGA
        
        if progress_callback:
            progress_callback(0, 0, 0, 0, "Initializing Genetic Algorithm...")
        
        ga = ScheduleGA(self.entities, self.constraints, self.config)
        
        def ga_progress(gen, best, avg, std):
            if progress_callback:
                progress = (gen / self.config.get("generations", 500)) * 100
                progress_callback(gen, best, avg, std, 
                                f"Generation {gen}: Best={best:.2f}, Avg={avg:.2f}")
        
        result = ga.evolve(progress_callback=ga_progress)
        result["method"] = "genetic"
        return result
    
    def optimize_hybrid(self, progress_callback):
        """Hybrid: Gemini seeding + GA evolution"""
        from lib.genetic_algo import ScheduleGA
        
        # Phase 1: Gemini generates initial solution (20% progress)
        if progress_callback:
            progress_callback(0, 0, 0, 0, "Phase 1: Gemini AI generating seed solution...")
        
        time.sleep(0.5)
        
        gemini_solution = self.gemini.generate_schedule_suggestions(
            self.entities, 
            self.constraints,
            context="This will be used as seed for genetic algorithm optimization.",
            config=self.config
        )
        
        if progress_callback:
            progress_callback(0, 0, 0, 0, "Phase 1: AI seed generated. Starting GA...")
        
        time.sleep(0.3)
        
        # Phase 2: Initialize GA with custom population
        if progress_callback:
            progress_callback(0, 0, 0, 0, "Phase 2: Initializing population with AI seed...")
        
        ga = ScheduleGA(self.entities, self.constraints, self.config)
        
        # Seed first individual with Gemini solution if valid
        if gemini_solution and len(gemini_solution) == len(self.entities):
            from deap import creator, base, tools
            creator.create("FitnessMax", base.Fitness, weights=(1.0,))
            ga.toolbox.register("individual", tools.initIterate, creator.Individual, ga.toolbox.individual)
            population = [creator.Individual(gemini_solution)]
            population_size = self.config.get("population_size", 100)
            population.extend([ga.toolbox.individual() for _ in range(population_size - 1)])
            ga.toolbox.register("population", lambda n: population)
                
        # Phase 3: Evolve with GA (80% progress)
        def ga_progress(gen, best, avg, std):
            if progress_callback:
                # Map generation progress to 20-100% range
                base_progress = 20
                ga_progress_pct = (gen / self.config.get("generations", 500)) * 80
                total_progress = base_progress + ga_progress_pct
                
                progress_callback(
                    gen, best, avg, std,
                    f"Phase 2: Evolution Gen {gen} | Best: {best:.2f} | Avg: {avg:.2f} | Std: {std:.2f}"
                )
        
        result = ga.evolve(progress_callback=ga_progress)
        result["method"] = "hybrid"
        result["gemini_seed"] = gemini_solution is not None
        
        if progress_callback:
            progress_callback(
                result.get("history", [{}])[-1].get("generation", 0),
                result["fitness"],
                result.get("history", [{}])[-1].get("avg_fitness", 0),
                result.get("history", [{}])[-1].get("std_fitness", 0),
                "✅ Optimization Complete!"
            )
        
        return result
